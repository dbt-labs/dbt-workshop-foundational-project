{% docs stg_circuit_desc %}
[![Spa](https://www.spa-francorchamps.be/sites/default/files/image/16.03.2022_logo_05.jpg)](https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.spa-francorchamps.be)


This is the staging model which has dimensional data for each F1 circuit.

{% enddocs %}

{% docs stg_constructors_desc %}
[![Constructors](https://www.grandprix247.com/wp-content/uploads/2020/11/pic1.jpg)](https://www.grandprix247.com/wp-content/uploads/2020/11/pic1.jpg)


This is the staging model for constructor dimensional data.

{% enddocs %}