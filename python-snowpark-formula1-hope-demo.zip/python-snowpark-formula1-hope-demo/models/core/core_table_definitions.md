{% docs dim_circuits %}

This table contains dimensional data related to F1 circuits.

{% enddocs %}